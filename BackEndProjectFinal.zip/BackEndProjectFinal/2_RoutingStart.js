
const moduleHTTP=require('http');
const httpServer=moduleHTTP.createServer((request,response)=>{
    if(request.url=='/'){
        response.statusCode=200;
        response.setHeader('Content-Type','text/plain');
        response.write('This is Home Page');
        response.end();
    }
    else if(request.url=='/about'){
        response.statusCode=200;
        response.setHeader('Content-Type','text/plain');
        response.write('This is About Page');
        response.end();
    }
    else{
        response.writeHead(404);
        response.write('This is Invalid URL\n');
        response.end(moduleHTTP.STATUS_CODES[404]);
    }   
})
const port=process.env.port||3000;
const hostName='localhost';
httpServer.listen(port,hostName,()=>{
    console.log('Server is up and running');
})

