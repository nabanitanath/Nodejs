function display(req){
    console.log('We are now on cotact-submit page');
    var email=req.body.email;
    var sub=req.body.sub;    
    var descr=req.body.descr;

    var MongoClient = require('mongodb').MongoClient;
    var url = "mongodb+srv://Nabanita:nabanita@cluster0.b51ry.mongodb.net/";

    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("nodejsdb");
        var myobj = { email: email, subject: sub, description:descr };
        dbo.collection("users").insertOne(myobj, function(err, res) {
            if (err) throw err;
            console.log("1 document inserted");
        db.close();
    });
    console.log('all well');
});
}

module.exports = {display};