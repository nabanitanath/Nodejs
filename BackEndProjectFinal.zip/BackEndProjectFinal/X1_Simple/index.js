var http=require('http');
var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var app = express();

// set up handlebars as view engine
var handlebars = require('express3-handlebars').create({ defaultLayout:'master' });
app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');
app.use(bodyParser.urlencoded({ extended: false}));
app.use(express.static(path.join(__dirname, 'public')))


//setting port
app.set('port', process.env.PORT || 3000);

//home page
app.get('/', function(req, res){
    //res.type('text/plain');
    //res.send('Travel Blog');
    res.render('home');
    });  
//about page
app.get('/about', function(req, res){
    //res.type('text/plain');
    //res.send('About Travel Blog');
    res.render('about');
    });
//contact page    
app.get('/contact', function(req, res){
    //res.type('text/plain');
   // res.send('Contact Page - Travel Blog');
   res.render('contact');
    });
app.post('/contact_subm', function(req,res){
    var x = require('./xmodule/contact_subm');
    x.display(req);
    res.render("contact_subm");
});
    
//tajmahal page
app.get('/tajmahal', function(req, res){
    res.render('tajmahal');
    });    
//covalam page
app.get('/covalam', function(req, res){
    res.render('covalam');
    }); 

// custom 404 page
app.use(function(req, res){
res.type('text/plain');
res.status(404);
res.send('404 - Not Found');
});
// custom 500 page
app.use(function(err, req, res, next){
console.error(err.stack);
res.type('text/plain');
res.status(500);
res.send('500 - Server Error');
});

//listen function to initiate the server
app.listen(app.get('port'), function(){
console.log( 'Express started on http://localhost:' +
app.get('port') + '; press Ctrl-C to terminate.' );
});