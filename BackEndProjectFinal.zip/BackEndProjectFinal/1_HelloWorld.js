
const moduleHTTP=require('http');
const httpServer=moduleHTTP.createServer((request,response)=>{
    response.statusCode=200;
    response.setHeader('Content-Type','text/plain');
    response.write('nodeJS App Server without ExpressJS.....');
    response.write('\n This is second line');

    response.end();
})

const port=process.env.port||3000;
const hostName='localhost';
httpServer.listen(port,hostName,()=>{
    console.log('Server is up and running');
})

